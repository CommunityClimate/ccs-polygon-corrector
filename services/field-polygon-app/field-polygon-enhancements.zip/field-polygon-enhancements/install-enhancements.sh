#!/bin/bash
# Field Polygon Validator - Enhancement Installation Script
# Version: 2.1
# Date: February 6, 2026

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Field Polygon Validator - Enhancement Installer"
echo "  Version 2.1 - Surgical Enhancements Package"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Check if we're in the right directory
if [ ! -f "app.js" ] || [ ! -d "config" ] || [ ! -d "core" ] || [ ! -d "ui" ]; then
    echo "❌ ERROR: This script must be run from your field-polygon-app directory"
    echo ""
    echo "Usage:"
    echo "  1. cd /path/to/field-polygon-app"
    echo "  2. bash install-enhancements.sh"
    echo ""
    exit 1
fi

echo "📁 Current directory: $(pwd)"
echo ""

# Ask for confirmation
echo "⚠️  This will update 5 files in your application:"
echo "   - config/app-config.js"
echo "   - core/polygon-validator.js"
echo "   - ui/ui-manager.js"
echo "   - app.js"
echo "   - index.html"
echo ""
read -p "❓ Do you want to create backups first? (y/n) " -n 1 -r
echo ""

if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo ""
    echo "💾 Creating backups..."
    
    BACKUP_DATE=$(date +%Y%m%d_%H%M%S)
    
    cp config/app-config.js "config/app-config.js.backup-$BACKUP_DATE"
    echo "   ✅ Backed up: config/app-config.js.backup-$BACKUP_DATE"
    
    cp core/polygon-validator.js "core/polygon-validator.js.backup-$BACKUP_DATE"
    echo "   ✅ Backed up: core/polygon-validator.js.backup-$BACKUP_DATE"
    
    cp ui/ui-manager.js "ui/ui-manager.js.backup-$BACKUP_DATE"
    echo "   ✅ Backed up: ui/ui-manager.js.backup-$BACKUP_DATE"
    
    cp app.js "app.js.backup-$BACKUP_DATE"
    echo "   ✅ Backed up: app.js.backup-$BACKUP_DATE"
    
    cp index.html "index.html.backup-$BACKUP_DATE"
    echo "   ✅ Backed up: index.html.backup-$BACKUP_DATE"
    
    echo ""
    echo "✅ All backups created with timestamp: $BACKUP_DATE"
    echo ""
fi

# Find the enhancement files
if [ -d "field-polygon-enhancements" ]; then
    ENHANCE_DIR="field-polygon-enhancements"
elif [ -f "../field-polygon-enhancements.zip" ]; then
    echo "📦 Extracting enhancements..."
    unzip -q ../field-polygon-enhancements.zip
    ENHANCE_DIR="field-polygon-enhancements"
else
    echo "❌ ERROR: Could not find field-polygon-enhancements directory or zip file"
    echo "   Please ensure field-polygon-enhancements.zip is in the parent directory"
    exit 1
fi

echo "🚀 Installing enhancements..."
echo ""

# Copy files
cp "$ENHANCE_DIR/config/app-config.js" config/
echo "   ✅ Updated: config/app-config.js"

cp "$ENHANCE_DIR/core/polygon-validator.js" core/
echo "   ✅ Updated: core/polygon-validator.js"

cp "$ENHANCE_DIR/ui/ui-manager.js" ui/
echo "   ✅ Updated: ui/ui-manager.js"

cp "$ENHANCE_DIR/app.js" .
echo "   ✅ Updated: app.js"

cp "$ENHANCE_DIR/index.html" .
echo "   ✅ Updated: index.html"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  ✅ INSTALLATION COMPLETE!"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "📋 Next Steps:"
echo ""
echo "   1. Open your application in a browser"
echo "   2. Open Developer Tools (F12)"
echo "   3. Run verification tests (see README.md)"
echo "   4. Test validation with sample polygons"
echo ""
echo "🧪 Quick Verification (paste in browser console):"
echo ""
echo "   console.log('Config:', APP_CONFIG.VERRA.MAX_GAP_CLOSURE_M);"
echo "   console.log('Function:', typeof UIManager.displayManualFixGuidance);"
echo "   console.log('Element:', !!document.getElementById('manual-fix-guidance'));"
echo ""
echo "   Expected: 0.5, 'function', true"
echo ""
echo "🔄 To rollback (if needed):"
echo "   cp config/app-config.js.backup-$BACKUP_DATE config/app-config.js"
echo "   (repeat for other files)"
echo ""
echo "📖 For more info, see: README.md in the enhancements package"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
